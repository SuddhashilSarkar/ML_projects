from flask import Flask, render_template, request, jsonify
import joblib

app = Flask(__name__)


# Main Page Route
@app.route('/')
def main_page():
    return render_template('index.html')


# Prediction Tool Route
@app.route('/prediction-tool')
def prediction_tool():
    return render_template(
        'prediction_tool.html'
    )  # Assuming you'll have a prediction_tool.html template


# Predictor API Route
@app.route('/predictor', methods=['POST'])
def predictor():
    data = request.json
    # Process your data here (e.g., make predictions using your SVM model)
    # For demonstration, let's assume we return a dummy prediction
    prediction = "benign" if data['mean_texture'] < 20 else "malignant"
    return jsonify({'prediction': prediction})


if __name__ == '__main__':
    app.run(debug=True)
